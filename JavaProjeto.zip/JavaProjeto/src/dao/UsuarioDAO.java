package dao;

import factory.ConnectionFactory;
import modelo.Usuario;
import java.sql.*;
import java.sql.PreparedStatement;

public class UsuarioDAO {
    private Connection connection;
    String id;
    String nome;
    String cpf;
    String email;
    String telefone;
    
    public UsuarioDAO(){
        this.connection = new ConnectionFactory().getConnection();
    }
    
    public void adiciona(Usuario usuarios){
        String sql = "INSERT INTO usuario (nome, cpf, email, telefone, id) VALUES (?,?,?,?,?)";
        try{
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, usuarios.getNome());
            stmt.setString(2, usuarios.getCpf());
            stmt.setString(3, usuarios.getEmail());
            stmt.setString(4, usuarios.getTelefone());
            stmt.setString(5, usuarios.getId());
            stmt.execute();
            stmt.close();
        }catch (SQLException u){
            throw new RuntimeException(u);
        }
    }
    
    public void remover(Usuario usuarios){
        String sql = "DELETE FROM `usuario` WHERE `usuario`.`id` = ?";
        try{
            PreparedStatement stmt = connection.prepareStatement(sql);
            
            //SE CÓDIGO É STRING
            stmt.setString(1, usuarios.getId());
            stmt.execute();
            stmt.close();
            connection.close();
            
        }catch (SQLException u){
            throw new RuntimeException(u);
        }
    }
    
    public void consultar(Usuario usuarios){
        String sql="select * from usuario where id= ?";
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1,usuarios.getId());
            stmt.executeQuery();
            stmt.execute();
            stmt.close();
            connection.close();

        } catch (Exception u) {
             throw new RuntimeException(u);
}
    }
}

